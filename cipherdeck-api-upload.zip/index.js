// CipherDeck API - Phase One Backend
// Full symbolic intake, lens, and vault framework

import express from "express";
import cors from "cors";

const app = express();
const PORT = process.env.PORT || 8080;

app.use(cors());
app.use(express.json());

// --- Core API Routes ---

// Health check
app.get("/api/ping", (req, res) => {
  res.json({ status: "CipherDeck backend live.", phase: "one" });
});

// Matrix intake endpoint
app.post("/api/matrix/upload", (req, res) => {
  const matrix = req.body;
  console.log("[Upload] Matrix received:", matrix);
  res.status(200).json({ message: "Matrix uploaded successfully." });
});

// Lens review endpoint
app.post("/api/lens/review", (req, res) => {
  const { matrixId, matrixData } = req.body;
  const review = {
    matrixId,
    rating: 7.8,
    lens_certified: true,
    symbolic_tags: ["stabilizer", "clarity", "structure"]
  };
  res.status(200).json(review);
});

// Certification endpoint
app.post("/api/matrix/certify", (req, res) => {
  const { matrixId } = req.body;
  res.status(200).json({ matrixId, certified: true });
});

// Vault status endpoint
app.get("/api/vault/status", (req, res) => {
  res.status(200).json({ certified_matrices: 104, launch_ready: true });
});

// Default root
app.get("/", (req, res) => {
  res.send("CipherDeck API - Phase One. Symbolic backend online.");
});

app.listen(PORT, () => {
  console.log(`🧬 CipherDeck API running on port ${PORT}`);
});
